# Krish Patel · Engineering Portfolio

Static portfolio site (plain HTML, CSS and JavaScript, no build step needed to host it).

## Structure

```
index.html                 Home: hero, projects, research, skills, about, contact
projects/*.html            One page per project (flowcharts, video, photos)
assets/css/style.css       All styles (light + dark theme)
assets/js/main.js          Theme toggle, menu, lightbox, oscilloscope simulations
assets/img/                Project images
assets/video/              Demo videos (H.264 MP4) and poster frames
assets/Krish_Patel_Resume.pdf
```

## Publish with GitHub Pages

1. Create a repository on GitHub. Naming it `krishpatelkp2423-dot.github.io` makes the site live at
   `https://krishpatelkp2423-dot.github.io`; any other name gives `https://krishpatelkp2423-dot.github.io/<repo-name>/`.
2. Upload everything in this folder to the repository root (keep the folder structure, including the empty `.nojekyll` file).
3. In the repository, open **Settings → Pages**, set **Source** to *Deploy from a branch*, choose `main` and `/ (root)`, and save.
4. The site goes live a minute or two later at the address shown on that page.

## Updating

- Swap the "KP" placeholder in the About section for a photo: add `assets/img/headshot.jpg` and replace the
  `<div class="portrait">…</div>` block in `index.html` with `<div class="portrait"><img src="assets/img/headshot.jpg" alt="Krish Patel"></div>`.
- Replace `assets/Krish_Patel_Resume.pdf` to update the résumé link everywhere.
